import { Component, OnInit } from '@angular/core';
import { Project } from '../project';
import { ProjectService } from '../project.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-search-project',
  templateUrl: './search-project.component.html',
  styleUrls: ['./search-project.component.css']
})
export class SearchProjectComponent implements OnInit {

  id: number;

  project: Project;
  submitted = false;
  constructor(private projectService: ProjectService) { }

  ngOnInit() {
    this.submitted = false;
  }

  search(): Project{
    this.submitted = true;
    this.projectService.searchProject(this.id).subscribe((data: Project) => { this.project = data; }, error => alert('no record found'));
    return this.project;

  }

  deleteProject(id: number) {
    this.projectService.deleteProject(id)
      .subscribe(
        data => {
          console.log(data);
          this.search();
        },
        error => console.log(error));
  }
 
}
