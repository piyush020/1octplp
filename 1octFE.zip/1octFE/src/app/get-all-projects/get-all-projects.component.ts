import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { Project } from "./../project";
import { ProjectService } from "./../project.service";

@Component({
  selector: 'app-get-all-projects',
  templateUrl: './get-all-projects.component.html',
  styleUrls: ['./get-all-projects.component.css']
})
export class GetAllProjectsComponent implements OnInit {

  //projects: Observable<Project[]>;

  projects: Project[];
  constructor(private projectService: ProjectService) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.projectService.displayAllProject().subscribe(data => this.projects = data, err => console.log(err));
  }

  deleteProject(id: number) {
    this.projectService.deleteProject(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

}
