import { Component, OnInit } from '@angular/core';
import { Project } from '../project';
import { ProjectService } from '../project.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-update-project',
  templateUrl: './update-project.component.html',
  styleUrls: ['./update-project.component.css']
})
export class UpdateProjectComponent implements OnInit {

  submitted = false;
  invalidDate = false;
  id: number;
  project: Project; // = { id: null, name: null, description: null, startDate: null, endDate: null, businessUnit: null };

  constructor(private projectService: ProjectService, private router: Router) { }

  ngOnInit() {
    this.submitted = false;
    this.invalidDate = false;
  }



  update() {
    this.submitted = true;
    this.projectService.searchProject(this.id).subscribe((data: Project) => {
      this.project = data;

      if (data != null) {

        this.project.startDate = new Date(data.startDate);

        this.project.endDate = new Date(data.endDate);
      }
      console.log(this.project);

    }, error => alert('no record found'));
    console.log(this.project);
  }

  changeStartDate(event) {
    this.project.startDate = new Date(event);
  }

  changeEndDate(event) {
    this.project.endDate = new Date(event);
  }

  updateProj() {
    console.log(this.project);
    this.project = this.projectService.getUpdateData(this.project);
    this.projectService.updateProject().subscribe((data: Project) => { this.project = data; });
  }

  compare() {
    if (this.project.startDate > this.project.endDate) {
      this.invalidDate = true;
    } else {
      this.invalidDate = false;
    }
  }
}
